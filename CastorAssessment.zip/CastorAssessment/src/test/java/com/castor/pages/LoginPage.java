/**
 * 
 */
package com.castor.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


/**
 * @author Kanchan Jahagirdar
* It stores elements present on Authentication/Login screen
 */
public class LoginPage  {
	
	WebDriver driver;
	
	
	
	public LoginPage(WebDriver driver)
	{
		this.driver = driver;
		
	}
	//String user name,String pwd
	public void SignToDdy(String username,String pwd) 
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.id("field-username")).sendKeys(username);	
		driver.findElement(By.id("field-password")).sendKeys(pwd);		
		driver.findElement(By.cssSelector(".Button.PrimaryButton")).click();
		
		
	}
	
	
}
