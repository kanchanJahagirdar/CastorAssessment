package com.castor.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
//DdySmallApp
@CucumberOptions(features="C:\\Users\\sanke\\eclipse-workspaceStudy\\CastorAssessment\\src\\test\\java\\CastorEDC.feature",
plugin={"pretty","html:target/Reports"},monochrome = true)
public class RunnerClass {

}
