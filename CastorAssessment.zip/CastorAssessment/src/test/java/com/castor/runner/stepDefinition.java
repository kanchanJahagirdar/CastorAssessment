package com.castor.runner;

/**
 * @author Kanchan Jahagirdar
 * This scripts contains all the step definitions required to Test DdySmall app
 */
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.castor.pages.LoginPage;
import com.castor.pages.NewRecordsPage;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDefinition {

public static WebDriver obj;
public static String systemPath;

	@Given("^Open Browser and Application$")
    public void url_opened(DataTable UrlLauch) {
		
	List<List<String>> Browserdata = UrlLauch.raw();
	//Here we decide which browser should be selected for execution
    systemPath=Browserdata.get(0).get(0);
    String browser = Browserdata.get(0).get(1);
	    if(browser.equals("chrome")){
		  	System.setProperty("webdriver.chrome.driver", systemPath+"\\chromedriver.exe");
		  	obj=new ChromeDriver();
		  	obj.manage().window().maximize();
			obj.manage().timeouts().implicitlyWait(100, TimeUnit.MILLISECONDS);
			obj.get("https://data.castoredc.com/");		
		}
		else{
			obj= new FirefoxDriver();
			obj.manage().window().maximize();
			obj.manage().timeouts().implicitlyWait(100, TimeUnit.MILLISECONDS);
			obj.get("https://data.castoredc.com/");
				}		   		  	      	      
    }
    		    
    @Then("^enter userid and password$")
    public void enter_userid_and_password(DataTable credentials) throws Throwable {
    	
	    LoginPage login = new LoginPage(obj);  
	    List<List<String>> Logindata = credentials.raw();	   
	    String email =Logindata.get(0).get(0);
	    String password = Logindata.get(0).get(1);
	    login.SignToDdy(email,password);
	    
    }
    
    @Given("^Navigate to Records Page$")
    @Then("^Open Records Page")
	public void open_records_page() throws InterruptedException {
    	 NewRecordsPage nrp = new NewRecordsPage(obj); 
    	 nrp.newRecordsPageDetails("https://data.castoredc.com/studies/qa-application-kanchan-jahagirdar/records");
	}

    public void create_new_record() throws InterruptedException{
    	//code to create record
    }
    
    public void performoperations() throws InterruptedException{
    	//code to maintain settings
    }
    
   public void selectradiobtn() throws InterruptedException{
	 //code to select radio btn
    }

   public void enterdetailsinInclusion() throws InterruptedException{
		 //code to Filling details in Inclusion
	    }
   public void enterdetailsinDemographics() throws InterruptedException{
		 //code to Filling details in Demographics
	    }
   public void enterdetailsinMeasurements() throws InterruptedException{
		 //code to Filling details in Measurements
	    }
   
    @Then("^CloseBrowser$")
	public void closeBrowser() 
	    {
		obj.close();
	   }
}