/**
 * 
 */
package com.castor.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * @author Kanchan Jahagirdar
* It stores elements present on New Account screen
 */
public class NewRecordsPage {

	WebDriver driver = null;
	
	
	public NewRecordsPage(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void newRecordsPageDetails(String url) 	{
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		//driver.navigate().to(url);
		
	}
	
}
